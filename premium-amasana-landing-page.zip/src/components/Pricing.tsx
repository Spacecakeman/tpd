"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";

export function Pricing() {
  return (
    <section id="book-yoga" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold tracking-tighter text-stone-900 mb-6">
            Join the <span className="italic font-light">Practice</span>
          </h2>
          <p className="text-lg text-stone-600">
            Intimate class sizes. Expert instructors. A space designed to help you disconnect and re-center.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Drop-in */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="p-8 rounded-3xl border border-stone-200 bg-stone-50"
          >
            <h3 className="text-xl font-bold text-stone-900 mb-2">Drop-in Session</h3>
            <p className="text-stone-500 mb-6 text-sm">Perfect for visitors or flexible schedules.</p>
            <div className="mb-8">
              <span className="text-4xl font-bold text-stone-900">$25</span>
              <span className="text-stone-500">/class</span>
            </div>
            <ul className="space-y-3 mb-8">
              <li className="flex items-center gap-3 text-stone-600 text-sm">
                <Check size={16} className="text-stone-900" /> Mat & props included
              </li>
              <li className="flex items-center gap-3 text-stone-600 text-sm">
                <Check size={16} className="text-stone-900" /> Herbal tea post-class
              </li>
            </ul>
            <button className="w-full py-3 px-6 bg-white border border-stone-200 text-stone-900 rounded-xl font-medium hover:bg-stone-100 transition-colors">
              Book a Class
            </button>
          </motion.div>

          {/* Membership */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="p-8 rounded-3xl bg-stone-900 text-white relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 bg-orange-500 text-xs font-bold px-3 py-1 rounded-bl-xl">POPULAR</div>
            <h3 className="text-xl font-bold mb-2">Amasana Member</h3>
            <p className="text-stone-400 mb-6 text-sm">For the dedicated practitioner.</p>
            <div className="mb-8">
              <span className="text-4xl font-bold">$120</span>
              <span className="text-stone-400">/month</span>
            </div>
            <ul className="space-y-3 mb-8">
              <li className="flex items-center gap-3 text-stone-300 text-sm">
                <Check size={16} className="text-orange-400" /> Unlimited monthly classes
              </li>
              <li className="flex items-center gap-3 text-stone-300 text-sm">
                <Check size={16} className="text-orange-400" /> Priority bread pre-orders
              </li>
              <li className="flex items-center gap-3 text-stone-300 text-sm">
                <Check size={16} className="text-orange-400" /> 10% off all artisan baked goods
              </li>
            </ul>
            <button className="w-full py-3 px-6 bg-orange-500 text-stone-900 rounded-xl font-bold hover:bg-orange-400 transition-colors shadow-lg shadow-orange-500/20">
              Become a Member
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
