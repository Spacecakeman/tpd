"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export function Hero() {
  return (
    <section className="relative min-h-[95vh] flex items-center pt-24 pb-16 overflow-hidden bg-stone-50">
      {/* Background Blobs/Gradients */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-orange-100/50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob" />
      <div className="absolute top-1/4 right-1/4 w-[400px] h-[400px] bg-stone-200/50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-2000" />
      <div className="absolute -bottom-32 left-1/2 w-[600px] h-[600px] bg-amber-50/50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-4000" />

      <div className="max-w-7xl mx-auto px-6 relative z-10 w-full grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-2xl"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/60 border border-stone-200/60 backdrop-blur-sm text-sm font-medium text-stone-600 mb-6 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-orange-400"></span>
            Tuesdays & Sundays
          </div>
          <h1 className="text-[clamp(3rem,6vw,5rem)] leading-[1.05] font-bold tracking-tighter text-stone-900 mb-6">
            Nourish the <span className="italic font-light text-stone-500">body.</span><br />
            Feed the <span className="italic font-light text-orange-700/80">soul.</span>
          </h1>
          <p className="text-lg md:text-xl text-stone-600 mb-8 leading-relaxed max-w-lg">
            Amasana brings together mindful movement and artisanal baking. Join our exclusive yoga sessions and order freshly baked sourdough, available twice a week.
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-4">
            <Link
              href="#book-yoga"
              className="w-full sm:w-auto px-8 py-4 bg-stone-900 text-white rounded-full font-medium hover:bg-stone-800 transition-all flex items-center justify-center gap-2 group shadow-lg shadow-stone-900/20"
            >
              Book Yoga Session
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              href="#order-bread"
              className="w-full sm:w-auto px-8 py-4 bg-white text-stone-900 rounded-full font-medium border border-stone-200 hover:bg-stone-50 transition-all flex items-center justify-center shadow-sm"
            >
              Order Artisan Bread
            </Link>
          </div>
          
          <div className="mt-10 flex items-center gap-4 text-sm text-stone-500">
            <div className="flex -space-x-3">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="w-10 h-10 rounded-full border-2 border-stone-50 bg-stone-200 overflow-hidden">
                  <img src={`https://i.pravatar.cc/100?img=${i + 10}`} alt="User" className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
            <p>Joined by <strong>2,000+</strong> mindful members.</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
          className="relative h-[600px] w-full hidden lg:block"
        >
          {/* Yoga Image */}
          <div className="absolute top-0 right-0 w-[80%] h-[70%] rounded-3xl overflow-hidden shadow-2xl">
            <img 
              src="https://images.pexels.com/photos/8436610/pexels-photo-8436610.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600" 
              alt="Yoga session" 
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
            />
          </div>
          
          {/* Bread Image Overlapping */}
          <div className="absolute bottom-10 left-0 w-[65%] h-[55%] rounded-3xl overflow-hidden shadow-[0_30px_60px_-15px_rgba(0,0,0,0.3)] border-4 border-stone-50">
            <img 
              src="https://images.pexels.com/photos/30632204/pexels-photo-30632204.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=500" 
              alt="Artisan Bread" 
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
            />
            {/* Glassmorphism Badge */}
            <div className="absolute bottom-4 left-4 right-4 bg-white/70 backdrop-blur-md border border-white/20 p-4 rounded-2xl flex items-center justify-between shadow-lg">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-stone-500">Next Bake</p>
                <p className="text-sm font-bold text-stone-900">Tuesday Morning</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 font-bold">
                24h
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
