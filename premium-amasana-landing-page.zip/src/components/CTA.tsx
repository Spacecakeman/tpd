"use client";

import { motion } from "framer-motion";
import Link from "next/link";

export function CTA() {
  return (
    <section className="relative py-32 overflow-hidden bg-stone-900 text-white">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.pexels.com/photos/8436684/pexels-photo-8436684.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1500" 
          alt="Yoga Studio" 
          className="w-full h-full object-cover opacity-20 mix-blend-overlay"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-900/80 to-transparent" />
      </div>

      <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-6xl font-bold tracking-tighter mb-8">
            Ready to find your <span className="italic font-light text-orange-400">center?</span>
          </h2>
          <p className="text-xl text-stone-300 mb-12 leading-relaxed max-w-2xl mx-auto">
            Whether you're here to stretch, breathe, or just pick up the best sourdough in town—we're ready to welcome you.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <Link
              href="#book-yoga"
              className="px-8 py-4 bg-orange-500 text-stone-900 rounded-full font-bold hover:bg-orange-400 transition-colors w-full sm:w-auto shadow-[0_0_40px_-10px_rgba(249,115,22,0.5)]"
            >
              Book Your First Class
            </Link>
            <Link
              href="#order-bread"
              className="px-8 py-4 bg-transparent border border-white/30 text-white rounded-full font-medium hover:bg-white/10 transition-colors w-full sm:w-auto backdrop-blur-sm"
            >
              Pre-order Bread
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
