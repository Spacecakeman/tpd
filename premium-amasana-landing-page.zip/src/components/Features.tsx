"use client";

import { motion } from "framer-motion";
import { Leaf, Wheat, CalendarHeart, Clock } from "lucide-react";

export function Features() {
  const features = [
    {
      title: "Mindful Movement",
      description: "Intimate, guided vinyasa and restorative yoga sessions designed to align body and breath.",
      icon: <Leaf className="w-6 h-6 text-emerald-600" />,
      bg: "bg-emerald-50",
      image: "https://images.pexels.com/photos/8436686/pexels-photo-8436686.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800"
    },
    {
      title: "Artisan Sourdough",
      description: "Naturally leavened, long-fermented bread baked fresh every Tuesday and Sunday morning.",
      icon: <Wheat className="w-6 h-6 text-orange-600" />,
      bg: "bg-orange-50",
      image: "https://images.pexels.com/photos/30853707/pexels-photo-30853707.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800"
    }
  ];

  return (
    <section id="features" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-20">
          <h2 className="text-3xl md:text-5xl font-bold tracking-tighter text-stone-900 mb-6">
            The Perfect <span className="italic font-light">Balance</span>
          </h2>
          <p className="text-lg text-stone-600">
            We believe in nourishing the whole self. That's why we combine the grounding practice of yoga with the simple, wholesome joy of fresh artisan bread.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {features.map((feature, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.7, delay: idx * 0.2 }}
              className="group"
            >
              <div className="relative h-[400px] rounded-3xl overflow-hidden mb-8 shadow-sm group-hover:shadow-xl transition-all duration-500">
                <div className="absolute inset-0 bg-stone-900/10 z-10 group-hover:bg-transparent transition-colors duration-500" />
                <img 
                  src={feature.image} 
                  alt={feature.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className={`absolute top-6 left-6 ${feature.bg} w-12 h-12 rounded-full flex items-center justify-center z-20 shadow-sm`}>
                  {feature.icon}
                </div>
              </div>
              <h3 className="text-2xl font-bold text-stone-900 mb-3">{feature.title}</h3>
              <p className="text-stone-600 text-lg leading-relaxed mb-6">{feature.description}</p>
              
              <div className="flex gap-4">
                <div className="flex items-center gap-2 text-sm font-medium text-stone-900 bg-stone-100 px-4 py-2 rounded-full">
                  <CalendarHeart className="w-4 h-4" />
                  Weekly Sessions
                </div>
                {idx === 1 && (
                  <div className="flex items-center gap-2 text-sm font-medium text-stone-900 bg-stone-100 px-4 py-2 rounded-full">
                    <Clock className="w-4 h-4" />
                    Tues & Sun Only
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
