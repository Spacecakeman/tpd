"use client";

import { motion } from "framer-motion";
import { Star } from "lucide-react";

export function Testimonials() {
  const testimonials = [
    {
      name: "Sarah Jenkins",
      role: "Yoga Practitioner",
      content: "The vinyasa flow classes are incredible, but picking up a fresh loaf of sourdough right after class makes my Sunday mornings absolute perfection.",
      rating: 5,
    },
    {
      name: "Marcus Torres",
      role: "Bread Enthusiast",
      content: "I started coming just for the bread on Tuesdays, but eventually tried the restorative yoga. It completely changed my routine. Highly recommend both!",
      rating: 5,
    },
    {
      name: "Emily Chen",
      role: "Local Resident",
      content: "Amasana is my sanctuary. The aroma of fresh baking bread mixed with the calming atmosphere of the studio is something you have to experience.",
      rating: 5,
    }
  ];

  return (
    <section id="testimonials" className="py-24 bg-stone-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold tracking-tighter text-stone-900 mb-4">
            Our Mindful <span className="italic font-light">Community</span>
          </h2>
          <p className="text-stone-600 text-lg">Don't just take our word for it.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.2, duration: 0.6 }}
              className="bg-white p-8 rounded-3xl shadow-sm border border-stone-100 hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex gap-1 mb-6 text-orange-400">
                {[...Array(t.rating)].map((_, idx) => (
                  <Star key={idx} size={18} fill="currentColor" />
                ))}
              </div>
              <p className="text-stone-700 mb-8 leading-relaxed">"{t.content}"</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-stone-200 overflow-hidden">
                  <img src={`https://i.pravatar.cc/150?img=${i + 30}`} alt={t.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="font-bold text-stone-900">{t.name}</p>
                  <p className="text-sm text-stone-500">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
