"use client";

import Link from "next/link";
import { Heart, Compass, MapPin, ArrowUpRight } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-stone-950 text-stone-400 py-16 border-t border-stone-900">
      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-4 gap-12">
        <div className="md:col-span-2">
          <Link href="/" className="inline-block mb-6">
            <span className="text-3xl font-bold tracking-tighter text-white">
              Amasana.
            </span>
          </Link>
          <p className="max-w-sm mb-8 leading-relaxed">
            Nourishing the body and feeding the soul through mindful movement and artisan baking.
          </p>
          <div className="flex gap-4">
            <a href="#" className="w-10 h-10 rounded-full bg-stone-900 flex items-center justify-center hover:bg-orange-500 hover:text-stone-900 transition-colors">
              <Heart size={18} />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-stone-900 flex items-center justify-center hover:bg-orange-500 hover:text-stone-900 transition-colors">
              <Compass size={18} />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-stone-900 flex items-center justify-center hover:bg-orange-500 hover:text-stone-900 transition-colors">
              <MapPin size={18} />
            </a>
          </div>
        </div>

        <div>
          <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Offerings</h4>
          <ul className="space-y-4">
            <li><Link href="#book-yoga" className="hover:text-white transition-colors flex items-center gap-1 group">Yoga Classes <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" /></Link></li>
            <li><Link href="#order-bread" className="hover:text-white transition-colors flex items-center gap-1 group">Artisan Bread <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" /></Link></li>
            <li><Link href="#" className="hover:text-white transition-colors flex items-center gap-1 group">Memberships <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" /></Link></li>
            <li><Link href="#" className="hover:text-white transition-colors flex items-center gap-1 group">Gift Cards <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" /></Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Company</h4>
          <ul className="space-y-4">
            <li><Link href="#" className="hover:text-white transition-colors">Our Story</Link></li>
            <li><Link href="#faq" className="hover:text-white transition-colors">FAQ</Link></li>
            <li><Link href="#" className="hover:text-white transition-colors">Contact</Link></li>
            <li><Link href="#" className="hover:text-white transition-colors">Privacy Policy</Link></li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 mt-16 pt-8 border-t border-stone-900 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-sm">© {new Date().getFullYear()} Amasana. All rights reserved.</p>
        <p className="text-sm">Designed with mindfulness.</p>
      </div>
    </footer>
  );
}
