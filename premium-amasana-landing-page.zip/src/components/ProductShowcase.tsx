"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";

export function ProductShowcase() {
  const benefits = [
    "Organic, locally milled flour",
    "48-hour slow fermentation",
    "Naturally leavened (no commercial yeast)",
    "Baked on stone hearths",
  ];

  return (
    <section id="bread" className="py-24 bg-stone-900 text-stone-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          <div className="absolute inset-0 bg-gradient-to-tr from-orange-900/40 to-transparent rounded-[3rem] transform -rotate-3 scale-105" />
          <img 
            src="https://images.pexels.com/photos/10024751/pexels-photo-10024751.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600" 
            alt="Artisan Sourdough" 
            className="relative rounded-[3rem] shadow-2xl object-cover w-full h-[600px] border border-stone-800"
          />
          
          {/* Floating detail badge */}
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="absolute -right-8 bottom-20 bg-stone-800/90 backdrop-blur-md p-6 rounded-3xl border border-stone-700 shadow-2xl max-w-xs"
          >
            <p className="text-orange-400 font-bold mb-1">Tuesdays & Sundays</p>
            <p className="text-stone-300 text-sm">Limited batches to ensure perfect crust and crumb. Pre-order recommended.</p>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold tracking-tighter mb-6">
            Bread Worth <br/>
            <span className="italic font-light text-orange-400">Waiting For.</span>
          </h2>
          <p className="text-lg text-stone-400 mb-8 leading-relaxed">
            Our signature rustic sourdough is a labor of love. We respect the ancient art of bread-making, using only flour, water, and salt to create complex flavors and deep nourishment.
          </p>

          <ul className="space-y-4 mb-10">
            {benefits.map((benefit, i) => (
              <li key={i} className="flex items-center gap-4">
                <div className="w-6 h-6 rounded-full bg-orange-900/50 flex items-center justify-center text-orange-400 flex-shrink-0">
                  <Check size={14} strokeWidth={3} />
                </div>
                <span className="text-stone-300">{benefit}</span>
              </li>
            ))}
          </ul>

          <div className="bg-stone-800/50 rounded-2xl p-6 border border-stone-700/50">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h4 className="font-bold text-lg">Signature Sourdough</h4>
                <p className="text-sm text-stone-400">850g Boule</p>
              </div>
              <p className="text-2xl font-light">$12</p>
            </div>
            <button className="w-full py-4 bg-orange-500 text-stone-900 rounded-xl font-bold hover:bg-orange-400 transition-colors">
              Pre-order for Tuesday
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
